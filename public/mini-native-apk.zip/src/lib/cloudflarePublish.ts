/**
 * cloudflarePublish.ts - Cloudflare R2 Direct Site Publishing Engine
 */

export const CLOUDFLARE_CONFIG = {
  accountId: "ff5a3d3ff28e65ee5c421618acf220f4",
  apiToken: "cfat_tWNIiSjtpo3rss5RALNLb8nUhnRqIkyFBqJ1Zmla28d6f5f9",
  accessKeyId: "7149d63c27fe12fe6cc2981ce3ffda04",
  secretAccessKey: "f33616c0dc8b11aa6184be4c7d3aea83f12f1558c9cde2a2ac45df639c176901",
  endpoint: "https://ff5a3d3ff28e65ee5c421618acf220f4.r2.cloudflarestorage.com",
  bucketName: "mini-ai-sites",
  publicDomain: "https://ff5a3d3ff28e65ee5c421618acf220f4.r2.cloudflarestorage.com/mini-ai-sites"
};

export async function publishToCloudflareR2(htmlCode: string, siteId: string): Promise<string> {
  const fileName = `sites/${siteId}/index.html`;
  try {
    const res = await fetch(`${CLOUDFLARE_CONFIG.endpoint}/${CLOUDFLARE_CONFIG.bucketName}/${fileName}`, {
      method: "PUT",
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Authorization": `Bearer ${CLOUDFLARE_CONFIG.apiToken}`,
        "x-amz-acl": "public-read"
      },
      body: htmlCode
    });

    if (res.ok) {
      return `${CLOUDFLARE_CONFIG.publicDomain}/${fileName}`;
    }
  } catch (err) {
    console.warn("Cloudflare R2 direct PUT fallback:", err);
  }

  // Fallback to app site view URL
  return `${window.location.origin}/site/${siteId}`;
}
