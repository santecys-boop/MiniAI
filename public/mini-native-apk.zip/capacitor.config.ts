import type { CapacitorConfig } from '@capacitor/cli';

// GERÇEK NATIVE MODU: Kod APK'nın içine gömülür, offline çalışır.
// Güncelleme için: kodu değiştir -> npm run build -> npx cap sync -> yeniden APK build.
const config: CapacitorConfig = {
  appId: 'app.lovable.f43b86e5ccf34666bec224f17bb41697',
  appName: 'Mini',
  webDir: 'dist',
  android: {
    allowMixedContent: true,
  },
};

export default config;
