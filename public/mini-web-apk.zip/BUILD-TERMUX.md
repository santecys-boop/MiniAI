# Mini — Hot-Reload APK (Termux Build)

Bu APK sadece bir "kabuk"tur. Açıldığında https://ai-site-craft-16.lovable.app adresini yükler.
Lovable'da site değişince APK'yı YENİDEN KURMANA GEREK YOK — sadece uygulamayı kapat aç.

## Termux'ta gerekli paketler (bir kere)

```bash
pkg update && pkg upgrade -y
pkg install -y nodejs-lts openjdk-17 gradle git wget unzip which
```

## Android SDK (Termux için)

Termux'ta Android SDK cmdline-tools kur:

```bash
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmd.zip
unzip cmd.zip && mv cmdline-tools latest && rm cmd.zip
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

Bu değişkenleri kalıcı yap:
```bash
echo 'export ANDROID_HOME=~/android-sdk' >> ~/.bashrc
echo 'export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0' >> ~/.bashrc
source ~/.bashrc
```

## Build

```bash
unzip mini-web-apk.zip -d mini-web && cd mini-web
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK burada olur:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Kur

```bash
cp android/app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/mini.apk
```
Sonra dosya yöneticisinden mini.apk'a tıkla, kur.

## Güncelleme

APK'yı bir kere kurdun. Sitede değişiklik yapınca APK'yı YENİDEN BUILD ETMENE GEREK YOK.
Sadece uygulamayı kapatıp aç — canlı siteyi çeker.
