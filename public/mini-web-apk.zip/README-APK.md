Bu paket HOT-RELOAD APK üretir. Detay: BUILD-TERMUX.md
