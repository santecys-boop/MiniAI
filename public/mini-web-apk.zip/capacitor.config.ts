import type { CapacitorConfig } from '@capacitor/cli';

// HOT-RELOAD MODU: APK açıldığında canlı siteden yüklenir.
// Sitede değişiklik yaparsan APK'yı yeniden kurmana gerek YOK.
const config: CapacitorConfig = {
  appId: 'app.lovable.f43b86e5ccf34666bec224f17bb41697',
  appName: 'Mini',
  webDir: 'dist',
  server: {
    url: 'https://ai-site-craft-16.lovable.app',
    cleartext: true,
    androidScheme: 'https',
  },
};

export default config;
